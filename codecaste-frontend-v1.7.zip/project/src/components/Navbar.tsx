import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Code2, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

function Navbar() {
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  
  const isActive = (path: string) => {
    return location.pathname === path ? 'text-emerald-500' : 'text-gray-600 dark:text-gray-300 hover:text-emerald-500';
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <Code2 className="h-8 w-8 text-emerald-500" />
              <span className="text-2xl font-semibold text-gray-900 dark:text-white">CodeCaste</span>
            </Link>
          </div>
          <div className="flex items-center space-x-8">
            <Link to="/" className={`${isActive('/')} font-medium`}>Home</Link>
            <Link to="/fix-code" className={`${isActive('/fix-code')} font-medium`}>Fix Code</Link>
            <Link to="/about" className={`${isActive('/about')} font-medium`}>About</Link>
            <Link to="/contact" className={`${isActive('/contact')} font-medium`}>Contact</Link>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? (
                <Moon className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              ) : (
                <Sun className="h-5 w-5 text-gray-300" />
              )}
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Navbar;