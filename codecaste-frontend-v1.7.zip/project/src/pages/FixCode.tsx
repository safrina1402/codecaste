import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';

const LANGUAGES = [
  'Python',
  'JavaScript',
  'TypeScript',
  'Java',
  'C++',
  'Ruby',
  'Go',
  'Rust',
];

function FixCode() {
  const [language, setLanguage] = useState('Python');
  const [code, setCode] = useState('');
  const [fixedCode, setFixedCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setFixedCode('');

    try {
      const response = await fetch('https://codecaste-backend.onrender.com/fix-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ language, code }),
      });

      if (!response.ok) {
        throw new Error('Failed to fix code. Please try again.');
      }

      const data = await response.json();
      setFixedCode(data.fixed_code);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Fix Your Code</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="language" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Programming Language
          </label>
          <select
            id="language"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 bg-white dark:bg-gray-700 dark:text-white p-2.5"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang} value={lang}>
                {lang}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="code" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Enter your buggy code
          </label>
          <textarea
            id="code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            rows={8}
            className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 font-mono bg-white dark:bg-gray-700 dark:text-white p-4"
            placeholder="Paste your code here..."
          />
        </div>

        <div>
          <button
            type="submit"
            disabled={isLoading || !code.trim()}
            className="w-full flex justify-center items-center gap-2 rounded-md bg-emerald-500 px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-emerald-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Fixing Code...
              </>
            ) : (
              'Fix My Code'
            )}
          </button>
        </div>

        {error && (
          <div className="rounded-md bg-red-50 dark:bg-red-900 p-4">
            <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
          </div>
        )}

        {fixedCode && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Fixed Code Output
            </label>
            <pre className="mt-1 block w-full rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 p-4 font-mono text-sm text-gray-900 dark:text-gray-100 overflow-auto">
              {fixedCode}
            </pre>
          </div>
        )}
      </form>
    </div>
  );
}

export default FixCode;