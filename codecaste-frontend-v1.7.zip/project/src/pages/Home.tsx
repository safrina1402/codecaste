import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Wand2 } from 'lucide-react';

function Home() {
  const navigate = useNavigate();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center">
        <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 dark:text-white mb-6">
          Fix your code, <span className="text-emerald-500">unleash its potential.</span>
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 max-w-3xl mx-auto">
          Transform buggy code into clean, efficient solutions with our AI-powered code fixer.
          Let CodeCaste help you write better code, faster.
        </p>
        <button
          onClick={() => navigate('/fix-code')}
          className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-500 text-white rounded-lg font-semibold hover:bg-emerald-600 transition-colors duration-200"
        >
          <Wand2 className="h-5 w-5" />
          Start Fixing
        </button>
      </div>
      
      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-4 dark:text-white">Smart Fixes</h3>
          <p className="text-gray-600 dark:text-gray-300">
            Advanced AI algorithms analyze and fix your code while maintaining its original intent.
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-4 dark:text-white">Multiple Languages</h3>
          <p className="text-gray-600 dark:text-gray-300">
            Support for various programming languages including Python, JavaScript, Java, and more.
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-4 dark:text-white">Instant Results</h3>
          <p className="text-gray-600 dark:text-gray-300">
            Get your fixed code in seconds, complete with explanations of the changes made.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Home;