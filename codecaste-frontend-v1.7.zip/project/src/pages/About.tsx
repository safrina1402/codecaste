import React from 'react';

function About() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">About CodeCaste</h1>
      
      <div className="prose prose-emerald dark:prose-invert max-w-none">
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
          CodeCaste is an AI-powered code fixing tool that helps developers write better, cleaner code.
          Using advanced machine learning models from Cohere, we analyze your code and suggest improvements
          while maintaining its original functionality.
        </p>

        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-12 mb-6">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-4 dark:text-white">1. Submit Code</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Paste your code and select the programming language you're working with.
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-4 dark:text-white">2. AI Analysis</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Our AI model analyzes your code for bugs, inefficiencies, and potential improvements.
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-4 dark:text-white">3. Get Results</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Receive your improved code along with explanations of the changes made.
            </p>
          </div>
        </div>

        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-12 mb-6">Technologies</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center mb-12">
          <img
            src="https://images.unsplash.com/photo-1687186735445-df877226fae9?q=80&w=150&auto=format&fit=crop"
            alt="Cohere"
            className="h-12 object-contain"
          />
          <img
            src="https://images.unsplash.com/photo-1686331226074-dbbac629b91e?q=80&w=150&auto=format&fit=crop"
            alt="FastAPI"
            className="h-12 object-contain"
          />
          <img
            src="https://images.unsplash.com/photo-1686331226987-10d0988d1948?q=80&w=150&auto=format&fit=crop"
            alt="Render"
            className="h-12 object-contain"
          />
          <img
            src="https://images.unsplash.com/photo-1686331227985-36520e758345?q=80&w=150&auto=format&fit=crop"
            alt="Netlify"
            className="h-12 object-contain"
          />
        </div>
      </div>
    </div>
  );
}

export default About;